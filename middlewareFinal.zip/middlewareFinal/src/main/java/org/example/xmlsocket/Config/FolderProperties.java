package org.example.xmlsocket.Config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConfigurationProperties(prefix = "folders")
public class FolderProperties {

    private List<String> salaryLoan;
    private List<String> other;

    public List<String> getSalaryLoan() {
        return salaryLoan;
    }

    public void setSalaryLoan(List<String> salaryLoan) {
        this.salaryLoan = salaryLoan;
    }

    public List<String> getOther() {
        return other;
    }

    public void setOther(List<String> other) {
        this.other = other;
    }
}
