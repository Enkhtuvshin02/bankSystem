package org.example.xmlsocket.MailService;

import lombok.Getter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.Map;

@Service
public class MailService {
    private static final Logger log = LoggerFactory.getLogger(MailService.class);
    @Getter
    private boolean mailSenderEnabled = true;
    @Autowired
    private RestTemplate restTemplate;
    public synchronized void senFailureMail(String subject, String message) {
        log.info("Attempting to send failure notification: {} : {}", subject, message);
        if (mailSenderEnabled) {
            try {
                String url = "http://192.168.205.190:8343/api/alertEmail/";
                String foreignMessage = "\r\n\r\n\r\n\r\n<!DOCTYPE html>\r\n\r\n<html>\r\n<body>\r\n" + message + "\r\n    <br /><br />\r\n    This email is created automatically and does not require a response.\r\n</body>\r\n</html>";
                Map<String, Object> requestBody = Collections.singletonMap("body", Collections.singletonList(Map.of(
                        "CIF", "",
                        "foreignMessage", foreignMessage,
                        "requestID", "SOFTPOS_8b7a3910-5200-4cdf-91c9-e60e23bda409",
                        "channel", "DMS",
                        "foreignSubject", subject,
                        "hostID", "TEST",
                        "alertID", "TEST",
                        "langID", "EN",
                        "email", "enkhtuvshin.enkh@golomtbank.com",
                        "senderFlag", "False"
                )));

                HttpHeaders headers = new HttpHeaders();
                headers.add("Content-Type", "application/json");

                HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

                ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);

                log.info("Response from server: {}", response);

                if (response.getStatusCode().is2xxSuccessful()) {
                    log.info("Sent failure notification to admin and disabled mail sender.");
                    mailSenderEnabled = false;
                } else {
                    log.error("Failed to send failure notification, server responded with status: {}, response body: {}", response.getStatusCode(), response.getBody());
                }
            } catch (Exception e) {
                log.error("Failed to send failure notification: {}", e.getMessage(), e);
            }
        } else {
            log.warn("Mail sender is currently disabled.");
        }
    }

    public synchronized void enableMailSender() {
        mailSenderEnabled = true;
        log.info("Mail sender has been enabled.");
    }

}
