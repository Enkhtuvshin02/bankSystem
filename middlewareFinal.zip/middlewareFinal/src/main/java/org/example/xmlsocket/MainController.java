package org.example.xmlsocket;

import org.example.xmlsocket.ProcessRequest.ProcessRequestService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.BlockingQueue;

@RestController
public class MainController {

    private static final Logger log = LoggerFactory.getLogger(MainController.class);
    private final ProcessRequestService processRequestService;
    private final BlockingQueue<ProcessingTask> taskQueue;

    @Autowired
    public MainController(ProcessRequestService processRequestService, BlockingQueue<ProcessingTask> taskQueue) {
        this.processRequestService = processRequestService;
        this.taskQueue = taskQueue;
        startWorkerThread();
    }

    @PostMapping("/addFolder")
    public ResponseEntity<Map<String, String>> addDocument(
            @RequestPart("file") MultipartFile file,
            @RequestPart("dataFile") MultipartFile dataFile
    ) {
        try {
            Path storedFile = storeFile(file);
            Path storedDataFile = storeFile(dataFile);

            ProcessingTask task = new ProcessingTask(storedFile, storedDataFile);
            taskQueue.put(task);

            Map<String, String> response = new HashMap<>();
            response.put("message", "Files uploaded successfully and processing will continue in the background");
            return ResponseEntity.ok(response);

        } catch (IOException | InterruptedException e) {
            log.error("Error storing files or adding to queue", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("error", "File storage or queueing failed"));
        }
    }

    private Path storeFile(MultipartFile file) throws IOException {
        Path persistentStorageDir = Path.of("D:/Documents/e20015150/Documents/dmsFileStorage");
        Path storedFile = persistentStorageDir.resolve(Objects.requireNonNull(file.getOriginalFilename()));
        Files.copy(file.getInputStream(), storedFile, StandardCopyOption.REPLACE_EXISTING);
        return storedFile;
    }

    private void startWorkerThread() {
        Thread workerThread = new Thread(() -> {
            while (true) {
                try {
                    ProcessingTask task = taskQueue.take();
                    processRequestService.processFolder(task.getStoredFile(), task.getStoredDataFile());
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    log.error("Worker thread interrupted", e);
                } catch (Exception e) {
                    log.error("Error processing task", e);
                }
            }
        });
        workerThread.setDaemon(true);
        workerThread.start();
    }

    public static class ProcessingTask {
        private final Path storedFile;
        private final Path storedDataFile;

        public ProcessingTask(Path storedFile, Path storedDataFile) {
            this.storedFile = storedFile;
            this.storedDataFile = storedDataFile;
        }

        public Path getStoredFile() {
            return storedFile;
        }

        public Path getStoredDataFile() {
            return storedDataFile;
        }
    }
}
