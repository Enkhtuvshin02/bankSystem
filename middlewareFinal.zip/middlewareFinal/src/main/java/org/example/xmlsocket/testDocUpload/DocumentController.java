package org.example.xmlsocket.testDocUpload;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api/documents")
public class DocumentController {

    @Autowired
    private DocumentService documentService;

    @PostMapping("/send")
    public String sendDocument(@RequestParam("file") MultipartFile file) throws IOException {
        return documentService.sendPostRequest(file);
    }
}
