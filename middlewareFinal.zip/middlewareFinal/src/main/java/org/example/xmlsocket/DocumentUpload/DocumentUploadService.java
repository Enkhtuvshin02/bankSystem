
package org.example.xmlsocket.DocumentUpload;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;
import java.util.Set;
import java.util.UUID;

@Service
public class DocumentUploadService {

    @Value("${username2}")
    private String username;

    @Value("${password}")
    private String password;

    public String login(WebDriver driver) {
        try {
            driver.get("http://192.168.209.97:8080/omnidocs/login.jsp");
            Set<Cookie> cookies = driver.manage().getCookies();
            String JSESSIONID1 = "";
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("JSESSIONID")) {
                    JSESSIONID1 = cookie.getValue();
                }
            }
            WebElement usernameInput = driver.findElement(By.cssSelector("input[type='text'][id='userName']"));
            WebElement passwordInput = driver.findElement(By.cssSelector("input[type='password'][id='password']"));
            usernameInput.sendKeys(username);
            passwordInput.sendKeys(password);
            WebElement loginButton = driver.findElement(By.cssSelector("input#login"));
            loginButton.click();
            try {
                Alert alert = driver.switchTo().alert();
                System.out.println(alert);
                alert.accept();
            } catch (NoAlertPresentException e) {
                System.out.println("No alert present");
            }
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
            if (wait.until(ExpectedConditions.titleContains("Welcome"))) {
                return JSESSIONID1;
            } else {
                return "failed login";
            }
        } catch (Exception e) {
            return "failed login";
        }
    }

    public String logout(String JSESSIONID1, String JSESSIONID2, String OD_UID) throws IOException {
        try {
            UUID uuid = UUID.randomUUID();
            String rid = uuid.toString().replace("-", "");
            String logoutUrl = "http://192.168.209.97:8080/omnidocs/weblogout.jsp?OD_UID=" + OD_UID + "&SaaSLogOutUrl=null";
            URL url = new URL(logoutUrl);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36");
            con.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7");
            con.setRequestProperty("Referer", "http://192.168.209.97:8080/omnidocs/webaccess/configurations/configList.jsp?rid=" + rid);
            con.setRequestProperty("Accept-Encoding", "gzip, deflate");
            con.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
            con.setRequestProperty("Cookie", "JSESSIONID=" + JSESSIONID1 + "; Register=noset; Check=noset; JSESSIONID=" + JSESSIONID2);
            int responseCode = con.getResponseCode();
            String inputLine = "";
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            return "success";
        } catch (Exception e) {
            return "failed logout";
        }
    }
}

