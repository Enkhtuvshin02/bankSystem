package org.example.xmlsocket.ProcessRequest;

import org.example.xmlsocket.SessionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;

@Component
public class ShutdownManager {

    private final SessionManager sessionManager;

    @Autowired
    public ShutdownManager(SessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }
    @PreDestroy
    public void onShutdown() {
        sessionManager.invalidateCabSession();
        System.out.println("Logged out successfully on shutdown.");
    }
}