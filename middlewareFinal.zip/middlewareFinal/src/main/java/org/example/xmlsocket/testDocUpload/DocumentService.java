package org.example.xmlsocket.testDocUpload;

import org.example.xmlsocket.SessionManager;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Duration;
import java.util.Objects;
import java.util.Set;

@Service
public class DocumentService {

    @Autowired
    private RestTemplate restTemplate;
    private final SessionManager sessionManager;
    private final WebDriver webDriver;

    public DocumentService(SessionManager sessionManager, WebDriver webDriver) {
        this.sessionManager = sessionManager;
        this.webDriver = webDriver;
    }

    public String sendPostRequest(MultipartFile file) throws IOException {
        String JSESSIONID1 = sessionManager.getSeleniumSessionId();
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.titleContains("Welcome"));
        String pageSource = webDriver.getPageSource();
        Set<Cookie> cookies = webDriver.manage().getCookies();
        String JSESSIONID2 = cookies.stream().filter(cookie -> "JSESSIONID".equals(cookie.getName()))
                .map(Cookie::getValue).findFirst().orElse("");
        Document doc = Jsoup.parse(pageSource);
        Element firstInput = Objects.requireNonNull(doc.select("form").last()).selectFirst("input");
        assert firstInput != null;
        String OD_UID = firstInput.attr("value");
        String url = "http://192.168.209.97:8080/omnidocs/webaccess/configurations/adddocument/closeadddoc.jsp?OD_UID="+OD_UID;
        HttpHeaders headers = new HttpHeaders();
        headers.set("Connection", "keep-alive");
        headers.set("Cache-Control", "max-age=0");
        headers.set("Upgrade-Insecure-Requests", "1");
        headers.set("Origin", "http://192.168.209.97:8080");
        headers.setContentType(MediaType.parseMediaType("multipart/form-data; boundary=----WebKitFormBoundaryY3bnvLu7RjqFCVEv"));
        headers.set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36");
        headers.set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7");
        headers.set("Referer", "http://192.168.209.97:8080/omnidocs/webaccess/configurations/adddocument/addDocument.jsp?DocListFolderId=481013&DocListFolderPath=Golomt/ТҮР/ХАВТАС/110/ЦАЛИНГИЙН+ЗЭЭЛ/R150007720+110+LA299+8888+ИДЭР+БАТЧУЛУУН&VolIndex=1&VolumeIndex=1&WebAccess=false&DocListFoldSearch=false&FoldViewAddDoc=false&OD_UID="+OD_UID);
        headers.set("Cookie", "Register=noset; Check=set; CabinetId=Golomt; UserId=e20015150;JSESSIONID="+JSESSIONID2);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("DocExt", "pdf");
        body.add("FolderId", "481013");
        body.add("FolderName", "");
        body.add("UserList", "");
        body.add("Option", "null");
        body.add("UserIndexList", "");
        body.add("UserIdList", "");
        body.add("DocListFolderId", "481013");
        body.add("DocListFolderPath", "Golomt/ТҮР/ХАВТАС/110/ЦАЛИНГИЙН+ЗЭЭЛ/R150007720+110+LA299+8888+ИДЭР+БАТЧУЛУУН");
        body.add("Comments", "");
        body.add("ParentOption", "");
        body.add("FullFolderName", "");
        body.add("VolIndex", "1");
        body.add("VolumeIndex", "1");
        body.add("WebAccess", "false");
        body.add("DocListFoldSearch", "false");
        body.add("FoldViewAddDoc", "false");
        body.add("dataClassIndex", "Salary_loan#1924");
        body.add("dataClassFields", "Харилцагчийн_CIF_ID.5571.S.R150007720.Харилцагчийн_нэр.5702.S.Регистрийн_дугаар." +
                "5619.S.УШ92020732.Үндсэн_дансны_дугаар.7139.S..Хүсэлтийн_төрөл.5704.S.Бүтээгдэхүүн." +
                "5705.S.LA299.Өргөдлийн_дугаар.5706.S.44.Бүс.7284.ТӨВИЙН БҮС.SOL_ID.5707.S.110.Огноо." +
                "5708.D.16/07/2024.Хамтран_зээлдэгч.5709.S.Байхгүй.Батлан_даагч." +
                "5710.S.Байхгүй.Нэмэлт_барьцаа.5711.S.Байхгүй.Судлах_нэгж." +
                "5712.S.САЛБАР.ХМ_Банкир.7317.S.test.Судлаач.5713.S..Архив.5714.S..Бусад_1." +
                "5715.S..Бусад_2.5716.S..Статус.7285.S..Зээлийн_дансны_дугаар." +
                "7141.S.1105056499.RM_Banker.5717.S..CIF_officer.5718.S..CIF_checker.5719.S..Loan_senior_officer.5720.S..Loan_checker.5721.S..Loan_officer.5722.S..Loan_assistance.5723.S..Contract_maker.5724.S..Contract_assistance.28122.S..Contract_checker.5725.S..Contract_senior.28123.S..Lawyer.28124.S..Director.28125.S..");
        body.add("RowCount", "0");
        body.add("scannedFilePath", "");
        body.add("Selradio", "SelectFile");
        body.add("F", new ByteArrayResource(file.getBytes()){
            @Override
            public String getFilename(){
                return "R150007720.pdf";
            }
        });
        body.add("DocName", "Зээлийн танилцуулга");
        body.add("DocComments", "");
        body.add("Keywords", "");

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);

        return restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class).getBody();
    }
}
