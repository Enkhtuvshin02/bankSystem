package org.example.xmlsocket.ProcessRequest;

import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.*;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class FolderCreationService {
    private static final Logger LOGGER = Logger.getLogger(FolderCreationService.class.getName());
    private final String serverIp = "192.168.209.97";
    private final int serverPort = 3333;
    private final int poolSize = 10;
    private final BlockingQueue<Socket> connectionPool = new ArrayBlockingQueue<>(poolSize);

    public FolderCreationService() {
        initializeConnectionPool();
    }

    private void initializeConnectionPool() {
        for (int i = 0; i < poolSize; i++) {
            try {
                connectionPool.add(new Socket(serverIp, serverPort));
            } catch (IOException e) {
                LOGGER.log(Level.SEVERE, "Failed to create socket connection to {0}:{1}", new Object[]{serverIp, serverPort});
                LOGGER.log(Level.SEVERE, e.getMessage(), e);
            }
        }
    }

    public String processRequest(String xmlIn) {
        Socket socket = null;
        try {
            socket = connectionPool.take();
            OutputStream outputStream = socket.getOutputStream();
            InputStream inputStream = socket.getInputStream();

            byte[] inputXmlBuffer = xmlIn.getBytes(StandardCharsets.UTF_8);
            byte[] inputXmlLength = ByteBuffer.allocate(4).putInt(inputXmlBuffer.length).array();
            outputStream.write(inputXmlLength);
            outputStream.write(inputXmlBuffer);

            byte[] recvBytes = new byte[4];
            inputStream.read(recvBytes);
            int bytesRead = ByteBuffer.wrap(recvBytes).getInt();
            byte[] finalBytes = new byte[bytesRead];
            int offset = 0;
            while (bytesRead > 0) {
                int bytesReadTemp = inputStream.read(finalBytes, offset, bytesRead);
                if (bytesReadTemp == -1) {
                    LOGGER.log(Level.SEVERE, "End of stream reached before reading expected data");
                    return null;
                }
                bytesRead -= bytesReadTemp;
                offset += bytesReadTemp;
            }
            return new String(finalBytes, StandardCharsets.UTF_8);
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "IOException occurred during request processing: {0}", e.getMessage());
            LOGGER.log(Level.SEVERE, e.getMessage(), e);
            return null;
        } catch (InterruptedException e) {
            LOGGER.log(Level.SEVERE, "Thread was interrupted: {0}", e.getMessage());
            Thread.currentThread().interrupt(); // restore interrupted status
            return null;
        } finally {
            if (socket != null) {
                connectionPool.offer(socket);
            }
        }
    }
    public String connectCab(String userName, String userPassword) {
        String xmlFormat = """
                <NGOConnectCabinet_Input>
                <Option>NGOConnectCabinet</Option>
                <CabinetName>Golomt</CabinetName>
                <UserName>%s</UserName>
                <UserPassword>%s</UserPassword>
                <UserExist>Y</UserExist>
                <ApplicationInfo>192.168.44.46</ApplicationInfo>
                <ApplicationName>OmniScan</ApplicationName>
                </NGOConnectCabinet_Input>
                """.formatted(userName, userPassword);

        return processRequest(xmlFormat);
    }

    // Creating folder
    public String addFolder(String[] folders, String sessionId, String folderName) {
        String parentIndex = "0";
        String response;
        boolean isFirstIteration = true;
        for (String folder : folders) {
            String xmlFormat = createAddFolderXml(sessionId, folder, isFirstIteration ? "" : "<ParentFolderIndex>" + parentIndex + "</ParentFolderIndex>");
            isFirstIteration = false;
            response = processRequest(xmlFormat);
            String status = extractValuesFromResponse(response, "Status");
            if ("-50018".equals(status)) { // Insufficient rights
                parentIndex = getFolderIndex(folder, parentIndex, sessionId);
            }
        }

        String xmlFormat = createAddFolderXml(sessionId, folderName, "<ParentFolderIndex>" + parentIndex + "</ParentFolderIndex>");
        return processRequest(xmlFormat);
    }

    private String createAddFolderXml(String sessionId, String folderName, String parentFolderIndex) {
        return """
                <NGOAddFolder_Input>
                <Option>NGOAddFolder</Option>
                <CabinetName>Golomt</CabinetName>
                <UserDBId>%s</UserDBId>
                <DuplicateName>N</DuplicateName>
                <Folder>
                <AccessType>I</AccessType>
                <FolderName>%s</FolderName>
                <NoOfDocuments>0</NoOfDocuments>
                <NoOfSubFolders>0</NoOfSubFolders>
                <NameLength>255</NameLength>
                <EnableFTSFlag>Y</EnableFTSFlag>
                %s
                </Folder>
                </NGOAddFolder_Input>
                """.formatted(sessionId, folderName, parentFolderIndex);
    }

    public String getFolderIndex(String folderName, String parentIndex, String sessionId) {
        String xmlFormat = """
                <NGOGetFolderIdForName_Input>
                <Option>NGOGetFolderIdForName</Option>
                <CabinetName>Golomt</CabinetName>
                <UserDBId>%s</UserDBId>
                <ParentFolderIndex>%s</ParentFolderIndex>
                <FolderName>%s</FolderName>
                </NGOGetFolderIdForName_Input>
                """.formatted(sessionId, parentIndex, folderName);

        String response = processRequest(xmlFormat);
        return extractValuesFromResponse(response, "FolderIndex");
    }

    public String getDataDefId(String name, String sessionId) {
        String xmlFormat = """
                <NGOGetDataDefIdForName_Input>
                <Option>NGOGetDataDefIdForName</Option>
                <CabinetName>Golomt</CabinetName>
                <UserDBId>%s</UserDBId>
                <DataDefName>%s</DataDefName>
                </NGOGetDataDefIdForName_Input>
                """.formatted(sessionId, name);

        String response = processRequest(xmlFormat);
        return extractValuesFromResponse(response, "DataDefIndex");
    }

    public String getDataDefProperty(String index, String sessionId) {
        String xmlFormat = """
                <NGOGetDataDefProperty_Input>
                <Option>NGOGetDataDefProperty</Option>
                <CabinetName>Golomt</CabinetName>
                <UserDBId>%s</UserDBId>
                <DataDefIndex>%s</DataDefIndex>
                </NGOGetDataDefProperty_Input>
                """.formatted(sessionId, index);

        return processRequest(xmlFormat);
    }

    public Map<String, String[]> getFieldTypeAndId(String xmlString) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new java.io.ByteArrayInputStream(xmlString.getBytes(StandardCharsets.UTF_8)));

        NodeList fields = doc.getElementsByTagName("Field");
        Map<String, String[]> indexMap = new LinkedHashMap<>();

        for (int i = 0; i < fields.getLength(); i++) {
            Element fieldElement = (Element) fields.item(i);
            String indexName = fieldElement.getElementsByTagName("IndexName").item(0).getTextContent();
            String indexId = fieldElement.getElementsByTagName("IndexId").item(0).getTextContent();
            String indexType = fieldElement.getElementsByTagName("IndexType").item(0).getTextContent();
            indexMap.put(indexName, new String[]{indexId, indexType});
        }
        return indexMap;
    }

    public Map<String, Object[]> addTypeAndIdToFormData(Map<String, Object> formData, Map<String, String[]> indexMap) {
        Map<String, Object[]> updatedFormData = new LinkedHashMap<>();
        for (Map.Entry<String, String[]> entry : indexMap.entrySet()) {
            String key = entry.getKey();
            String[] typeAndId = entry.getValue();
            Object value = formData.getOrDefault(key, "");
            updatedFormData.put(key, new Object[]{value, typeAndId[0], typeAndId[1]});
        }
        return updatedFormData;
    }

    public String changeFolderProperty(Map<String, Object[]> indexMap, String folderIndex, String sessionId, String dataDefIndex) {
        StringBuilder xmlFormat = new StringBuilder();
        xmlFormat.append("<NGOChangeFolderProperty_Input>").append(System.lineSeparator())
                .append("<Option>NGOChangeFolderProperty</Option>").append(System.lineSeparator())
                .append("<TSSubOption>NGOAssociateDataDef</TSSubOption>").append(System.lineSeparator())
                .append("<CabinetName>Golomt</CabinetName>").append(System.lineSeparator())
                .append("<UserDBId>").append(sessionId).append("</UserDBId>").append(System.lineSeparator())
                .append("<Folder>").append(System.lineSeparator())
                .append("<FolderIndex>").append(folderIndex).append("</FolderIndex>").append(System.lineSeparator())
                .append("<DataDefinition>").append(System.lineSeparator())
                .append("<DataDefIndex>").append(dataDefIndex).append("</DataDefIndex>").append(System.lineSeparator())
                .append("<Fields>").append(System.lineSeparator());

        for (Map.Entry<String, Object[]> entry : indexMap.entrySet()) {
            xmlFormat.append("<Field>").append(System.lineSeparator())
                    .append("<IndexId>").append(entry.getValue()[1]).append("</IndexId>").append(System.lineSeparator())
                    .append("<IndexType>").append(entry.getValue()[2]).append("</IndexType>").append(System.lineSeparator())
                    .append("<IndexValue>").append(entry.getValue()[0]).append("</IndexValue>").append(System.lineSeparator())
                    .append("</Field>").append(System.lineSeparator());
        }
        xmlFormat.append("</Fields>").append(System.lineSeparator())
                .append("</DataDefinition>").append(System.lineSeparator())
                .append("</Folder>").append(System.lineSeparator())
                .append("</NGOChangeFolderProperty_Input>");
        return processRequest(xmlFormat.toString());
    }

    public String getDocumentIdForName(String folderIndex, String sessionId, String documentName, String fileExtension) {
        String xmlFormat = """
                <NGOGetDocumentIdForName_Input>
                <Option>NGOGetIDFromName</Option>
                <CabinetName>Golomt</CabinetName>
                <UserDBId>%s</UserDBId>
                <Index>%s</Index>
                <ObjectType>D</ObjectType>
                <ObjectName>%s</ObjectName>
                <CreatedByAppName>%s</CreatedByAppName>
                </NGOGetDocumentIdForName_Input>
                """.formatted(sessionId, folderIndex, documentName, fileExtension);
        return processRequest(xmlFormat);
    }

    public String changeDocumentProperty(Map<String, Object[]> indexMap, String documentIndex, String sessionId, String dataDefIndex) {
        StringBuilder xmlFormat = new StringBuilder();
        xmlFormat.append("<NGOChangeDocumentProperty_Input>").append(System.lineSeparator())
                .append("<Option>NGOChangeDocumentProperty</Option>").append(System.lineSeparator())
                .append("<TSSubOption>NGOAssociateDataDef</TSSubOption>").append(System.lineSeparator())
                .append("<CabinetName>Golomt</CabinetName>").append(System.lineSeparator())
                .append("<UserDBId>").append(sessionId).append("</UserDBId>").append(System.lineSeparator())
                .append("<Document>").append(System.lineSeparator())
                .append("<DocumentIndex>").append(documentIndex).append("</DocumentIndex>").append(System.lineSeparator())
                .append("<DataDefinition>").append(System.lineSeparator())
                .append("<DataDefIndex>").append(dataDefIndex).append("</DataDefIndex>").append(System.lineSeparator())
                .append("<Fields>").append(System.lineSeparator());

        for (Map.Entry<String, Object[]> entry : indexMap.entrySet()) {
            xmlFormat.append("<Field>").append(System.lineSeparator())
                    .append("<IndexId>").append(entry.getValue()[1]).append("</IndexId>").append(System.lineSeparator())
                    .append("<IndexType>").append(entry.getValue()[2]).append("</IndexType>").append(System.lineSeparator())
                    .append("<IndexValue>").append(entry.getValue()[0]).append("</IndexValue>").append(System.lineSeparator())
                    .append("</Field>").append(System.lineSeparator());
        }

        xmlFormat.append("</Fields>").append(System.lineSeparator())
                .append("</DataDefinition>").append(System.lineSeparator())
                .append("</Document>").append(System.lineSeparator())
                .append("</NGOChangeDocumentProperty_Input>");
        return processRequest(xmlFormat.toString());
    }

    public String disConnectCab(String sessionId) {
        String disXmlStr = """
                <NGODisconnectCabinet_Input>
                <Option>NGODisconnectCabinet</Option>
                <CabinetName>Golomt</CabinetName>
                <UserDBId>%s</UserDBId>
                </NGODisconnectCabinet_Input>
                """.formatted(sessionId);
        return processRequest(disXmlStr);
    }

    public String extractValuesFromResponse(String xmlString, String field) {
        if (xmlString == null || xmlString.trim().isEmpty() || field == null || field.trim().isEmpty()) {
            LOGGER.log(Level.SEVERE, "XML String or field is null or empty. Unable to parse.");
            return "";
        }
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try (StringReader stringReader = new StringReader(xmlString)) {
            DocumentBuilder builder = factory.newDocumentBuilder();
            InputSource is = new InputSource(stringReader);
            Document doc = builder.parse(is);
            XPathFactory xPathfactory = XPathFactory.newInstance();
            XPath xpath = xPathfactory.newXPath();
            XPathExpression expr = xpath.compile("//" + field);
            NodeList nodeList = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
            if (nodeList.getLength() > 0) {
                return nodeList.item(0).getTextContent();
            } else if(!field.equals("UserDBId")){
                LOGGER.log(Level.WARNING, "Field "+field+" not found in XML response: "+xmlString);
            }
        } catch (SAXParseException e) {
            LOGGER.log(Level.SEVERE, "Invalid XML format: " + e.getMessage(), e);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Exception during XML parsing: " + e.getMessage(), e);
        }
        return "";
    }
}
