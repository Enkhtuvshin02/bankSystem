package org.example.xmlsocket.ProcessRequest;

import org.example.xmlsocket.Config.FolderService;
import org.example.xmlsocket.DocumentUpload.DocumentUploadComponent;
import org.example.xmlsocket.Exceptions.DMSServerDownException;
import org.example.xmlsocket.Exceptions.FileUploadFailedException;
import org.example.xmlsocket.MailService.MailService;
import org.example.xmlsocket.SessionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Service
public class ProcessRequestService {

    private static final Logger log = LoggerFactory.getLogger(ProcessRequestService.class);
    private final FolderCreationService folderCreationService;
    private final SessionManager sessionManager;
    private final DocumentUploadComponent documentUploadComponent;
    private final MailService mailService;
    private String sessionId;
    private final FolderService folderService;

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    @Autowired
    public ProcessRequestService(FolderCreationService folderCreationService, SessionManager sessionManager, DocumentUploadComponent documentUploadComponent, MailService mailService, FolderService folderService) {
        this.folderCreationService = folderCreationService;
        this.sessionManager = sessionManager;
        this.documentUploadComponent = documentUploadComponent;
        this.mailService = mailService;
        this.folderService = folderService;
    }

    public String[] getFoldersArray(String arrayKey) {
        return folderService.getFolderArray(arrayKey);
    }

    private String getDataDefName(Path tempDataFile) throws IOException {
        Map<String, Object> data = FileUtils.readJsonData(tempDataFile);
        return (String) data.get("dataDef");
    }

    private String constructFolderName(Map<String, Object> formData) {
        return formData.get("Харилцагчийн_CIF_ID") + " " + formData.get("SOL_ID") + " " + formData.get("Бүтээгдэхүүн") + " " + formData.get("Өргөдлийн_дугаар") + " " + formData.get("Харилцагчийн_нэр");
    }

    private String attemptReLogin() {
        try {
            String reLoginStatus = sessionManager.connectCabLogin();
            if ("0".equals(reLoginStatus) || "-50167".equals(reLoginStatus)) {
                this.sessionId = sessionManager.getCabSessionId();
                return sessionManager.getCabSessionId();
            } else {
                throw new DMSServerDownException("Server down, login failed");
            }
        } catch (DMSServerDownException e) {
            handleException(e);
            return null;
        }
    }

    @Retryable(value = Exception.class, maxAttempts = 2, backoff = @Backoff(delay = 6000, maxDelay = 12000))
    public void processFolder(Path tempFile, Path tempDataFile) {
        log.info("Starting folder processing");
        try {
            sessionId = sessionManager.getCabSessionId();
            String fileName = FileUtils.updateLastExecutedMethod(tempDataFile, "processFolder");
            Map<String, Object> data = FileUtils.readJsonData(tempDataFile);
            ensureSession();
            Map<String, Object> formData = (Map<String, Object>) data.get("formData");
            String dataDefName = data.get("DataDefName").toString();
            String docName = data.get("DocName").toString();
            formData.put("Харилцагчийн_CIF_ID", data.get("Харилцагчийн_CIF_ID"));
            formData.put("SOL_ID", data.get("SOL_ID"));
            String folderName = constructFolderName(formData);
            String[] folders = getFoldersArray(dataDefName);

            folders = Arrays.copyOf(folders, folders.length + 1);
            Map<String, Object[]> updatedFormData = new HashMap<>();
            String dataDefId = "";
            dataDefId = folderCreationService.getDataDefId(dataDefName, sessionId);
            handleDataDefinition(dataDefName, dataDefId, formData, folders, folderName, docName, tempFile, tempDataFile);
        } catch (IOException e) {
            handleException(e);
        } catch (Exception e) {
            handleException(e);
        }
    }

    private void ensureSession() {
        try {
         sessionManager.ensureCabLoggedIn();
            this.sessionId = sessionManager.getCabSessionId();
            if (this.sessionId == null || this.sessionId.isEmpty()) {
                log.info("Session ID is null, attempting to log in...");
                String reLoginStatus = sessionManager.connectCabLogin();
                if ("-50167".equals(reLoginStatus)) {
                    this.sessionId = sessionManager.getCabSessionId();
                    if (!mailService.isMailSenderEnabled()) {
                        mailService.enableMailSender();
                    }
                } else {
                    log.error("Unable to log in, server might be down");
                    throw new DMSServerDownException("Server down, unable to log in");
                }
            } else {
                if (!mailService.isMailSenderEnabled()) {
                    mailService.enableMailSender();
                }
            }
        } catch (DMSServerDownException e) {
            handleException(e);
        }
    }

    private void handleDataDefinition(String dataDefName, String dataDefId, Map<String, Object> formData, String[] folders, String folderName, String docName, Path tempFile, Path tempDataFile) throws Exception {
        if (this.sessionId == null) {
            throw new DMSServerDownException("Session ID is null, login failed");
        }
        String dataDefResponse = folderCreationService.getDataDefProperty(dataDefId, this.sessionId);
        if (!"0".equals(folderCreationService.extractValuesFromResponse(dataDefResponse, "Status"))) {
            log.info("Retrieving data definition failed, attempting re-login...");
            this.sessionId = attemptReLogin();
            dataDefResponse = folderCreationService.getDataDefProperty(dataDefId, this.sessionId);
        }

        Map<String, String[]> fieldsWithTypeAndId = folderCreationService.getFieldTypeAndId(dataDefResponse);
        Map<String, Object[]> updatedFormData = folderCreationService.addTypeAndIdToFormData(formData, fieldsWithTypeAndId);

        String addFolderResponse = folderCreationService.addFolder(folders, this.sessionId, folderName);
        if (!"0".equals(folderCreationService.extractValuesFromResponse(addFolderResponse, "Status")) && !"-50124".equals(folderCreationService.extractValuesFromResponse(addFolderResponse, "Status"))) {
            log.info("Adding folder failed, attempting re-login...");
            this.sessionId = attemptReLogin();
            addFolderResponse = folderCreationService.addFolder(folders, this.sessionId, folderName);
        }
        System.out.println("add folder response "+addFolderResponse);
        String folderIndex = folderCreationService.extractValuesFromResponse(addFolderResponse, "FolderIndex");
        if ("0".equals(folderCreationService.extractValuesFromResponse(addFolderResponse, "Status"))) {
            String changeFolderPropertyResponse = folderCreationService.changeFolderProperty(updatedFormData, folderIndex, this.sessionId, dataDefId);
            if (!"0".equals(folderCreationService.extractValuesFromResponse(changeFolderPropertyResponse, "Status"))) {
                log.info("Changing folder property failed, attempting re-login...");
                this.sessionId = attemptReLogin();
                changeFolderPropertyResponse = folderCreationService.changeFolderProperty(updatedFormData, folderIndex, this.sessionId, dataDefId);
            }
        }

        String contentType = Files.probeContentType(tempFile);
        String fileExtension = contentType.substring(contentType.lastIndexOf('/') + 1);
        fileExtension = "pdf".equalsIgnoreCase(fileExtension) ? "PDF" : "TIFF";
        String checkDocResponse = folderCreationService.getDocumentIdForName(folderIndex, this.sessionId, docName, fileExtension);

        saveToRedis(tempDataFile.getFileName().toString(), folderIndex, folderName, docName, updatedFormData, dataDefId);
        if ("0".equals(folderCreationService.extractValuesFromResponse(checkDocResponse, "Status"))) {
            processDoc(tempFile, tempDataFile, folderIndex, folderName, docName, updatedFormData, dataDefId);
        } else if ("-50023".equals(folderCreationService.extractValuesFromResponse(checkDocResponse, "Status"))) {
            uploadDoc(dataDefName, tempFile, tempDataFile, folderIndex, docName, folderName, updatedFormData, dataDefId);
        } else {
            this.sessionId = attemptReLogin();
            checkDocResponse = folderCreationService.getDocumentIdForName(folderIndex, this.sessionId, docName, fileExtension);
            if ("0".equals(folderCreationService.extractValuesFromResponse(checkDocResponse, "Status"))) {
                processDoc(tempFile, tempDataFile, folderIndex, folderName, docName, updatedFormData, dataDefId);
            } else if ("-50023".equals(folderCreationService.extractValuesFromResponse(checkDocResponse, "Status"))) {
                uploadDoc(dataDefName, tempFile, tempDataFile, folderIndex, docName, folderName, updatedFormData, dataDefId);
            }
        }
    }


    @Retryable(value = Exception.class, maxAttempts = 2, backoff = @Backoff(delay = 60000, maxDelay = 120000))
    protected void uploadDoc(String dataDefName, Path tempFile, Path tempDataFile, String folderIndex, String docName, String folderName, Map<String, Object[]> updatedFormData, String dataDefId) throws IOException {
        log.info("Starting document upload");
        String[] folders = getFoldersArray(dataDefName);
        try {
            ensureSession();
            String fileName = FileUtils.updateLastExecutedMethod(tempDataFile, "uploadDoc");

            MultipartFile multipartFile = FileUtils.convertPathToMultipartFile(tempFile);
            String addDocResponse = documentUploadComponent.processAndUploadDocument(multipartFile, folderIndex, docName, folders);
            if (!"ok".equals(addDocResponse)) {
                throw new FileUploadFailedException("Adding document failed:" + addDocResponse);
            }
            processDoc(tempFile, tempDataFile, folderIndex, folderName, docName, updatedFormData, dataDefId);
        } catch (IOException e) {
            log.error("IOException during document upload", e);
            handleException(e);
        } catch (Exception e) {
            handleException(e);
        }
    }


    @Retryable(value = Exception.class, maxAttempts = 2, backoff = @Backoff(delay = 60000, maxDelay = 120000))
    public void uploadDoc(Path tempFile, Path tempDataFile, String fileName) {
        log.info("Starting document upload with folders");
        try {
            ensureSession();
            Map<Object, Object> redisData = getRedisData(fileName);
            String folderIndex = (String) redisData.get("folderIndex");
            String docName = (String) redisData.get("docName");
            String folderName = (String) redisData.get("folderName");
            String dataDefId = (String) redisData.get("dataDefId");
            Map<String, Object[]> updatedFormData = (Map<String, Object[]>) redisData.get("updatedFormData");
            Map<String, Object> data = FileUtils.readJsonData(tempDataFile);
            String dataDefName = data.get("DataDefName").toString();
            String[] folders = getFoldersArray(dataDefName);
            MultipartFile multipartFile = FileUtils.convertPathToMultipartFile(tempFile);
            String addDocResponse = documentUploadComponent.processAndUploadDocument(multipartFile, folderIndex, docName, folders);
            if (!"ok".equals(addDocResponse)) {
                throw new FileUploadFailedException("Adding document failed:" + addDocResponse);
            }
            processDoc(tempFile, tempDataFile, folderIndex, folderName, docName, updatedFormData, dataDefId);
        } catch (IOException e) {
            log.error("IOException during document upload", e);
            handleException(e);
        } catch (Exception e) {
            handleException(e);
        }
    }

    @Retryable(value = Exception.class, maxAttempts = 2, backoff = @Backoff(delay = 60000, maxDelay = 120000))
    protected void processDoc(Path tempFile, Path tempDataFile, String folderIndex, String folderName, String docName, Map<String, Object[]> updatedFormData, String dataDefId) {
        log.info("Processing document with data definition ID: {}", dataDefId);
        String fileName = null;
        try {
            ensureSession();
            fileName = FileUtils.updateLastExecutedMethod(tempDataFile, "processDoc");
            String contentType = Files.probeContentType(tempFile);
            String fileExtension = contentType.substring(contentType.lastIndexOf('/') + 1);
            fileExtension = "pdf".equalsIgnoreCase(fileExtension) ? "PDF" : "TIFF";

            String checkDocResponse = folderCreationService.getDocumentIdForName(folderIndex, this.sessionId, docName, fileExtension);
            if (!"0".equals(folderCreationService.extractValuesFromResponse(checkDocResponse, "Status"))) {
                log.info("Document not found, attempting re-login...");
                this.sessionId = attemptReLogin();
                checkDocResponse = folderCreationService.getDocumentIdForName(folderIndex, this.sessionId, docName, fileExtension);
            }

            String documentIndex = folderCreationService.extractValuesFromResponse(checkDocResponse, "ObjectIndex");
            String changeDocumentPropertyResponse = folderCreationService.changeDocumentProperty(updatedFormData, documentIndex, this.sessionId, dataDefId);
            if (!"0".equals(folderCreationService.extractValuesFromResponse(changeDocumentPropertyResponse, "Status"))) {
                log.info("Changing document property failed, attempting re-login...");
                this.sessionId = attemptReLogin();
                changeDocumentPropertyResponse = folderCreationService.changeDocumentProperty(updatedFormData, documentIndex, this.sessionId, dataDefId);
            }

            cleanupFiles(fileName, tempFile, tempDataFile);
        } catch (IOException e) {
            log.error("IOException during document processing", e);
            saveToRedis(fileName, folderIndex, folderName, docName, updatedFormData, dataDefId);
            handleException(e);
        } catch (Exception e) {
            log.error("Exception during document processing", e);
            saveToRedis(fileName, folderIndex, folderName, docName, updatedFormData, dataDefId);
            handleException(e);
        }
    }

    @Retryable(value = Exception.class, maxAttempts = 2, backoff = @Backoff(delay = 60000, maxDelay = 120000))
    public void processDoc(Path tempFile, Path tempDataFile, String fileName) {
        log.info("Processing document with folder structure: {}");
        try {
            ensureSession();
            Map<Object, Object> redisData = getRedisData(fileName);
            String folderIndex = (String) redisData.get("folderIndex");
            String docName = (String) redisData.get("docName");
            String folderName = (String) redisData.get("folderName");
            String dataDefId = (String) redisData.get("dataDefId");
            Map<String, Object[]> updatedFormData = (Map<String, Object[]>) redisData.get("updatedFormData");
            String contentType = Files.probeContentType(tempFile);
            String fileExtension = contentType.substring(contentType.lastIndexOf('/') + 1);
            fileExtension = "pdf".equalsIgnoreCase(fileExtension) ? "PDF" : "TIFF";

            String checkDocResponse = folderCreationService.getDocumentIdForName(folderIndex, this.sessionId, docName, fileExtension);
            if (!"0".equals(folderCreationService.extractValuesFromResponse(checkDocResponse, "Status"))) {
                log.info("Document not found, attempting re-login...");
                this.sessionId = attemptReLogin();
                checkDocResponse = folderCreationService.getDocumentIdForName(folderIndex, this.sessionId, docName, fileExtension);
            }
            System.out.println("check doc response " + checkDocResponse);

            String documentIndex = folderCreationService.extractValuesFromResponse(checkDocResponse, "ObjectIndex");
            String changeDocumentPropertyResponse = folderCreationService.changeDocumentProperty(updatedFormData, documentIndex, this.sessionId, dataDefId);
            System.out.println("change  doc property response " + checkDocResponse);
            if (!"0".equals(folderCreationService.extractValuesFromResponse(changeDocumentPropertyResponse, "Status"))) {
                log.info("Changing document property failed, attempting re-login...");
                this.sessionId = attemptReLogin();
                changeDocumentPropertyResponse = folderCreationService.changeDocumentProperty(updatedFormData, documentIndex, this.sessionId, dataDefId);
            }
            cleanupFiles(fileName, tempFile, tempDataFile);
        } catch (IOException e) {
            log.error("IOException during document processing", e);
            handleException(e);
        } catch (Exception e) {
            log.error("Exception during document processing", e);
            handleException(e);
        }
    }

    public void cleanupFiles(String fileName, Path... paths) {
        deleteRedisData(fileName);
        for (Path path : paths) {
            try {
                Files.deleteIfExists(path);
                log.info("Successfully cleaned up temporary files for: {}", path);
            } catch (IOException e) {
                log.error("Failed to delete temporary file: {}", path, e);
            }
        }
    }


    private void handleException(Exception e) {
        log.warn("Handled exception of type {}: {}", e.getClass().getName(), e.getMessage());
        // Get the stack trace element where the exception was thrown
        StackTraceElement[] stackTraceElements = e.getStackTrace();
        if (stackTraceElements.length > 0) {
            StackTraceElement element = stackTraceElements[0]; // The first element is typically where the exception was thrown
            String exceptionLocation = "Exception occurred in " + element.getClassName() + " at " + element.getFileName() + ":" + element.getLineNumber();
            log.warn(exceptionLocation);

            if (e instanceof DMSServerDownException || e instanceof FileUploadFailedException) {
                mailService.senFailureMail("Exception Occurred", "Exception of type " + e.getClass().getName() + " occurred: " + e.getMessage());
            }
        } else {

            if (e instanceof DMSServerDownException || e instanceof FileUploadFailedException) {
                mailService.senFailureMail("Exception Occurred", "Exception of type " + e.getClass().getName() + " occurred: " + e.getMessage());
            }
        }
    }


    public void saveToRedis(String uniqueKey, String folderIndex, String folderName, String docName, Map<String, Object[]> updatedFormData, String dataDefId) {
        String redisKey = "Doc:" + uniqueKey;
        Boolean exists = redisTemplate.hasKey(redisKey);
        if (Boolean.FALSE.equals(exists)) {
            log.info("Saving data to Redis with key: {}", redisKey);
            Map<String, Object> dataToSave = new HashMap<>();
            dataToSave.put("folderIndex", folderIndex);
            dataToSave.put("docName", docName);
            dataToSave.put("folderName", folderName);
            dataToSave.put("updatedFormData", updatedFormData);
            dataToSave.put("dataDefId", dataDefId);
            log.info("Data to save: {}", dataToSave);
            redisTemplate.opsForHash().putAll(redisKey, dataToSave);
        } else {
            log.info("Data for key {} already exists in Redis. Skipping save.", redisKey);
        }
    }

    public Map<Object, Object> getRedisData(String uniqueKey) {
        String redisKey = "Doc:" + uniqueKey;
        log.info("Getting Redis data for key {}", redisKey);
        Map<Object, Object> redisData = redisTemplate.opsForHash().entries(redisKey);
        log.info("Retrieved data: {}", redisData);
        if (redisData == null || redisData.isEmpty()) {
            log.warn("No data found in Redis for key {}", redisKey);
            return null;
        }
        log.info("Successfully retrieved data for key {}: {}", redisKey, redisData);
        return redisData;
    }

    public void deleteRedisData(String uniqueKey) {
        String redisKey = "Doc:" + uniqueKey;
        log.info("Attempting to delete data for key: {}", redisKey);
        Boolean deleted = redisTemplate.delete(redisKey);
        if (Boolean.TRUE.equals(deleted)) {
            log.info("Successfully deleted data for key: {}", redisKey);
        } else {
            log.error("Failed to delete data for key: {}", redisKey);
        }
    }
}
