
package org.example.xmlsocket.ProcessRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
public class FileUtils {
    private static final ObjectMapper objectMapper = new ObjectMapper();
    public static String updateLastExecutedMethod(Path dataFile, String methodName) throws IOException {
        Map<String, Object> data = readJsonData(dataFile);
        System.out.println("Updating last executed method: " + methodName);
        data.put("lastExecutedMethod", methodName);
        String updatedJsonContent = objectMapper.writeValueAsString(data);
        Files.write(dataFile, updatedJsonContent.getBytes(StandardCharsets.UTF_8));
        return dataFile.getFileName().toString();
    }

    public static Map<String, Object> readJsonData(Path dataFile) throws IOException {
        byte[] bytes = Files.readAllBytes(dataFile);
        return objectMapper.readValue(bytes, Map.class);
    }
    public static MultipartFile convertPathToMultipartFile(Path path) throws IOException {
        String fileName = path.getFileName().toString();
        String contentType = Files.probeContentType(path);
        byte[] content = Files.readAllBytes(path);

        return new MockMultipartFile(fileName, fileName, contentType, content);
    }
}

