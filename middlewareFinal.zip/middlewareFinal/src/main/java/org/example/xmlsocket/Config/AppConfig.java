package org.example.xmlsocket.Config;

import org.example.xmlsocket.MainController;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

@Configuration
public class AppConfig {
    @Bean
    public BlockingQueue<MainController.ProcessingTask> taskQueue() {
        return new LinkedBlockingQueue<>();
    }
}
