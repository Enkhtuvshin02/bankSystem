package org.example.xmlsocket.Exceptions;

public class FileUploadFailedException extends Exception {
    public FileUploadFailedException(String message) {
        super(message);
    }

    public FileUploadFailedException(String message, Throwable cause) {
        super(message, cause);
    }
}
