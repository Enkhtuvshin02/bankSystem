package org.example.xmlsocket.Scheduler;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FileMatcher {
    private static final Logger log = LoggerFactory.getLogger(FileMatcher.class);

    public static List<String[]> findMatchingFilePairs(String directoryPath) throws IOException {
        System.out.println(directoryPath);
        List<String[]> matchedFilePairs = new ArrayList<>();
        Map<String, List<String>> filesByName = new HashMap<>();
        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(Paths.get(directoryPath))) {
            for (Path filePath : directoryStream) {
                if (Files.isRegularFile(filePath)) {
                    String fileName = filePath.getFileName().toString();
                    String baseName = FilenameUtils.getBaseName(fileName);
                    String extension = FilenameUtils.getExtension(fileName);
                    if (!filesByName.containsKey(baseName)) {
                        filesByName.put(baseName, new ArrayList<>());
                    }
                    filesByName.get(baseName).add(filePath.toString());
                }
            }
        }

        // Match files by base name
        for (Map.Entry<String, List<String>> entry : filesByName.entrySet()) {
            String baseName = entry.getKey();
            List<String> fileList = entry.getValue();
            String jsonFile = null;
            String pdfFile = null;
            String tifFile = null;
            for (String filePath : fileList) {
                if (filePath.endsWith(".json")) {
                    jsonFile = filePath;
                } else if (filePath.endsWith(".pdf")) {
                    pdfFile = filePath;
                }else if (filePath.endsWith(".tif")) {
                    tifFile = filePath;
                }
            }
            if (jsonFile != null && pdfFile != null) {
                matchedFilePairs.add(new String[]{jsonFile, pdfFile});
                log.info("Matched file pair: JSON -> {}, PDF -> {}", jsonFile, pdfFile);
            }else if (jsonFile != null && tifFile != null) {
                matchedFilePairs.add(new String[]{jsonFile, tifFile});
                log.info("Matched file pair: JSON -> {}, TIF -> {}", jsonFile, tifFile);
            }
        }
        return matchedFilePairs;
    }
}
