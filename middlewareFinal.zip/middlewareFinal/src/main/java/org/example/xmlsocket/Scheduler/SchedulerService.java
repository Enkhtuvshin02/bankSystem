package org.example.xmlsocket.Scheduler;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import org.example.xmlsocket.MainController;
import org.example.xmlsocket.ProcessRequest.ProcessRequestService;
import org.example.xmlsocket.SessionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;

@Component
public class SchedulerService {

    private static final Logger log = LoggerFactory.getLogger(SchedulerService.class);
    private static final ObjectMapper objectMapper = new ObjectMapper();
    @Getter
    private final BlockingQueue<MainController.ProcessingTask> taskQueue;
    @Autowired
    private ProcessRequestService processRequestService;
    @Autowired
    private SessionManager sessionManager;

    @Value("${scheduler.fixedRate}")
    private long fixedRate;

    @Value("${scheduler.jobDelay}")
    private long jobDelay;
    @Autowired
    public SchedulerService(BlockingQueue<MainController.ProcessingTask> taskQueue) {
        this.taskQueue = taskQueue;
    }

    @Scheduled(fixedRateString = "${scheduler.fixedRate}")
    public void runScheduler() {
        if (taskQueue.isEmpty()) {
            if (!sessionManager.checkServer()) {
                log.info("Server is down. Scheduler will retry after {} milliseconds.", fixedRate);
                return;
            }
            log.info("Server is up. Starting scheduled job.");
            executeJob();
        } else {
            log.info("Task queue is not empty.");
        }
    }
    private void executeJob() {
        try {
            System.out.println("Executing scheduler job.");
            List<String[]> matchedFilePairs = FileMatcher.findMatchingFilePairs("D:/Documents/e20015150/Documents/dmsFileStorage");
            Boolean checker = matchedFilePairs.isEmpty();
            System.out.println(checker);
            if (matchedFilePairs.isEmpty()) {
                log.info("No matching file pairs found. Scheduler will stop and retry at the next scheduled time.");
                return;
            }

            for (String[] filePair : matchedFilePairs) {
                Path dataFilePath = Paths.get(filePair[0]);
                String fileName = dataFilePath.getFileName().toString();
                System.out.println("Executing scheduler job for file " + fileName);
                Path documentFilePath = Path.of(filePair[1]);
                String lastExecutedMethod = readLastExecutedMethod(dataFilePath);
                log.info("Resuming operation from last executed method: {}", lastExecutedMethod);

                if ("processFolder".equals(lastExecutedMethod) || lastExecutedMethod.isEmpty()) {
                    processRequestService.processFolder(documentFilePath, dataFilePath);
                } else if ("uploadDoc".equals(lastExecutedMethod)) {
                    processRequestService.uploadDoc(documentFilePath, dataFilePath, fileName);
                } else if ("processDoc".equals(lastExecutedMethod)) {
                    processRequestService.processDoc(documentFilePath, dataFilePath, fileName);
                }
                Thread.sleep(jobDelay);
            }
        } catch (IOException e) {
            log.error("Failed to process files: {}", e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private String readLastExecutedMethod(Path dataFilePath) throws IOException {
        byte[] jsonData = Files.readAllBytes(dataFilePath);
        Map<String, Object> data = objectMapper.readValue(jsonData, Map.class);
        return (String) data.getOrDefault("lastExecutedMethod", "");
    }
}
