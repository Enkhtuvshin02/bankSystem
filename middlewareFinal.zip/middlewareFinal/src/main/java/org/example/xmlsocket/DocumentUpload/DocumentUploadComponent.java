package org.example.xmlsocket.DocumentUpload;

import org.example.xmlsocket.SessionManager;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;
import java.util.Objects;
import java.util.Set;

@Component
public class DocumentUploadComponent {

    private static final Logger logger = LoggerFactory.getLogger(DocumentUploadComponent.class);

    private final SessionManager sessionManager;
    private final WebDriver webDriver;

    @Autowired
    public DocumentUploadComponent(SessionManager sessionManager, WebDriver webDriver) {
        this.sessionManager = sessionManager;
        this.webDriver = webDriver;
    }

    public String processAndUploadDocument(MultipartFile file, String folderId, String docName, String[] folders) throws IOException {
        System.out.println(file.getOriginalFilename() +" "+folderId+ "Called in document upload component");
        String currentSessionId = sessionManager.getSeleniumSessionId();
        if (currentSessionId == null || currentSessionId.isEmpty()) {
            throw new IllegalStateException("Session ID is null or empty. Initial login may have failed.");
        }
        return uploadDocumentToServer(file, folderId, docName, folders);
    }

    private String uploadDocumentToServer(MultipartFile file, String folderId, String docName, String[] folders) throws IOException {
        String folderName = "R150007720 110 LA299 22 ИДЭР БАТЧУЛУУН";
        String JSESSIONID1 = sessionManager.getSeleniumSessionId();
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.titleContains("Welcome"));
        String pageSource = webDriver.getPageSource();
        Set<Cookie> cookies = webDriver.manage().getCookies();
        String JSESSIONID2 = cookies.stream().filter(cookie -> "JSESSIONID".equals(cookie.getName()))
                .map(Cookie::getValue).findFirst().orElse("");
        Document doc = Jsoup.parse(pageSource);
        Element firstInput = doc.select("form").last().selectFirst("input");
        String OD_UID = firstInput.attr("value");

        String path = String.join("/", folders);
        path = path.replace(" ", "+");
        String contentType = file.getContentType();
        String fileExtension = contentType.substring(contentType.lastIndexOf('/') + 1);
        folderName = folderName.replaceAll("\\s+", "+");
        URL addDocUrl = new URL("http://192.168.209.97:8080/omnidocs/webaccess/configurations/adddocument/closeadddoc.jsp?OD_UID=" + OD_UID);
        HttpURLConnection addDocCon = (HttpURLConnection) addDocUrl.openConnection();
        addDocCon.setRequestMethod("POST");
        addDocCon.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36");
        addDocCon.setRequestProperty("Content-Type", "multipart/form-data; boundary=----WebKitFormBoundarybC2fzbM85eZ2qu4p");
        addDocCon.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7");
        addDocCon.setRequestProperty("Referer", "http://192.168.209.97:8080/omnidocs/webaccess/configurations/adddocument/addDocument.jsp?DocListFolderId=24541&DocListFolderPath=Golomt/" + path + "/" + folderName + "&VolIndex=1&VolumeIndex=1&WebAccess=false&DocListFoldSearch=false&FoldViewAddDoc=false&OD_UID=" + OD_UID);
        addDocCon.setRequestProperty("Accept-Encoding", "gzip, deflate");
        addDocCon.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
        addDocCon.setRequestProperty("Cookie", "JSESSIONID=" + JSESSIONID1 + "; Register=noset; Check=noset;  JSESSIONID=" + JSESSIONID2);
        addDocCon.setDoOutput(true);
        String boundary = "----WebKitFormBoundarybC2fzbM85eZ2qu4p";
        byte[] fileBytes = file.getBytes();
        StringBuilder requestBody = new StringBuilder();
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"DocExt\"\r\n\r\n").append(fileExtension).append("\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"FolderId\"\r\n\r\n").append(folderId).append("\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"FolderName\"\r\n\r\n").append("\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"UserList\"\r\n\r\n").append("\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"Option\"\r\n\r\n").append("null\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"UserIndexList\"\r\n\r\n").append("\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"UserIdList\"\r\n\r\n").append("\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"DocListFolderId\"\r\n\r\n").append(folderId).append("\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"DocListFolderPath\"\r\n\r\n").append("Golomt/" + path + "/" + folderName + "\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"Comments\"\r\n\r\n").append("\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"ParentOption\"\r\n\r\n").append("\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"FullFolderName\"\r\n\r\n").append("\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"VolIndex\"\r\n\r\n").append("1\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"VolumeIndex\"\r\n\r\n").append("1\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"WebAccess\"\r\n\r\n").append("false\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"DocListFoldSearch\"\r\n\r\n").append("false\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"FoldViewAddDoc\"\r\n\r\n").append("false\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"dataClassIndex\"\r\n\r\n").append("Select#0\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"dataClassFields\"\r\n\r\n").append("\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"RowCount\"\r\n\r\n").append("0\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"scannedFilePath\"\r\n\r\n").append("\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"Selradio\"\r\n\r\n").append("SelectFile\r\n");
        requestBody.append("--").append(boundary).append("\r\n");
        requestBody.append("Content-Disposition: form-data; name=\"F\"; filename=\"").append(file.getOriginalFilename()).append("\"\r\n");
        requestBody.append("Content-Type: ").append(file.getContentType()).append("\r\n\r\n");
        OutputStream outputStream = addDocCon.getOutputStream();
        outputStream.write(requestBody.toString().getBytes());
        outputStream.write(fileBytes);
        outputStream.write(("\r\n--" + boundary + "\r\n").getBytes());
        StringBuilder remainingFields = new StringBuilder();
        remainingFields.append("Content-Disposition: form-data; name=\"DocName\"\r\n\r\n").append(docName).append("\r\n");
        remainingFields.append("--").append(boundary).append("\r\n");
        remainingFields.append("Content-Disposition: form-data; name=\"DocComments\"\r\n\r\n").append("\r\n");
        remainingFields.append("--").append(boundary).append("\r\n");
        remainingFields.append("Content-Disposition: form-data; name=\"KeyWords\"\r\n\r\n").append("\r\n");
        remainingFields.append("--").append(boundary).append("--\r\n");
        outputStream.write(remainingFields.toString().getBytes());
        outputStream.flush();
        outputStream.close();

        int responseCode = addDocCon.getResponseCode();
        InputStream responseBodyStream;
        if (responseCode == HttpURLConnection.HTTP_OK) {
            responseBodyStream = addDocCon.getInputStream();
        } else {
            responseBodyStream = addDocCon.getErrorStream();
        }

        BufferedReader reader = new BufferedReader(new InputStreamReader(responseBodyStream));
        StringBuilder responseBody = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            responseBody.append(line);
        }
        reader.close();
        String responseBodyString = responseBody.toString();
        System.out.println("Response Body: " + responseBodyString);

        String res = String.valueOf(responseCode);
        if (responseCode != HttpURLConnection.HTTP_OK) {
            return res;
        } else {
            return "ok";
        }
    }
    }
