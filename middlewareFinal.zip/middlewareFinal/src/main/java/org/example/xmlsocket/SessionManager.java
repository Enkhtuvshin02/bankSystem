package org.example.xmlsocket;

import lombok.Getter;
import org.example.xmlsocket.DocumentUpload.DocumentUploadService;
import org.example.xmlsocket.ProcessRequest.FolderCreationService;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Component
public class SessionManager {

    private String sessionId;
    @Getter
    private String seleniumSessionId;
    private final FolderCreationService folderCreationService;
    private final DocumentUploadService seleniumService;
    private final WebDriver webDriver;
    private final BlockingQueue<MainController.ProcessingTask> taskQueue;

    @Autowired
    public SessionManager(FolderCreationService folderCreationService, DocumentUploadService seleniumService, WebDriver webDriver, BlockingQueue<MainController.ProcessingTask> taskQueue) {
        this.folderCreationService = folderCreationService;
        this.seleniumService = seleniumService;
        this.webDriver = webDriver;
        this.taskQueue = taskQueue;
    }

    @PostConstruct
    public void initialize() {
        String response = folderCreationService.connectCab("e20015150","90535307Aa");
        this.sessionId = folderCreationService.extractValuesFromResponse(response,"UserDBId");
        System.out.println(sessionId);
        this.seleniumSessionId = seleniumLogin();
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(this::refreshSessions, 15, 15, TimeUnit.MINUTES);
    }

    public void ensureCabLoggedIn() {
        if (this.sessionId == null || this.sessionId.isEmpty()) {
            this.sessionId = connectCabLogin();
        }
    }

    public String connectCabLogin() {
        String connectResponse = folderCreationService.connectCab("e20015150", "90535307Aa");
        String status = folderCreationService.extractValuesFromResponse(connectResponse,"Status");
        if("-50167".equals(status)) {
            return this.sessionId;
        }else if("0".equals(status)) {
            return folderCreationService.extractValuesFromResponse(connectResponse, "UserDBId");
        }else{
            return null;
        }
    }
    public void invalidateCabSession() {
        if (sessionId != null && !sessionId.isEmpty()) {
            folderCreationService.disConnectCab(sessionId);
            this.sessionId = null;
        }
    }
    public String getCabSessionId() {
        return sessionId;
    }
    public Boolean checkServer() {
        String connectResponse = folderCreationService.connectCab("e20015150", "90535307Aa");
        String status = folderCreationService.extractValuesFromResponse(connectResponse, "Status");
        if ("0".equals(status)) {
            this.sessionId = folderCreationService.extractValuesFromResponse(connectResponse, "UserDBId");
            return true;
        } else if("-50167".equals(status)) {
            return true;
        }else{
            return false;
        }
    }
    //Selenium component Login
    private String seleniumLogin() {
        String seleniumLoginResponse = seleniumService.login(webDriver);
        System.out.println("seleniumLogin response"+seleniumLoginResponse);
        return seleniumLoginResponse;
    }

    private void refreshSessions() {
        if (taskQueue.isEmpty()) {
            this.sessionId = connectCabLogin();
            this.seleniumSessionId = seleniumLogin();
            System.out.println("Sessions refreshed: cabSessionId=" + sessionId + ", seleniumSessionId=" + seleniumSessionId);
        } else {
            System.out.println("Queue is not empty. Skipping session refresh.");
        }
    }
}
