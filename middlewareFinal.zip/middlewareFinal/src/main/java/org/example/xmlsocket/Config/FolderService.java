package org.example.xmlsocket.Config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FolderService {

    @Autowired
    private FolderProperties folderProperties;

    public String[] getFolderArray(String folderName) {
        List<String> folderList;

        switch (folderName.toUpperCase()) {
            case "SALARY_LOAN":
                folderList = folderProperties.getSalaryLoan();
                break;
            case "OTHER":
                folderList = folderProperties.getOther();
                break;
            default:
                throw new IllegalArgumentException("Invalid folder name: " + folderName);
        }

        return folderList.toArray(new String[0]);
    }
}
