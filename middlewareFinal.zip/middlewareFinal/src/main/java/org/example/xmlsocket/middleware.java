package org.example.xmlsocket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
@Retryable
@EnableAsync
@EnableRetry
@EnableScheduling
@SpringBootApplication(scanBasePackages = {"org.example.xmlsocket"})
public class middleware {

    public static void main(String[] args) {
        SpringApplication.run(middleware.class, args);
    }
}
