package org.example.xmlsocket.Exceptions;
public class DMSServerDownException extends Exception {
    public DMSServerDownException(String message) {
        super(message);
    }

    public DMSServerDownException(String message, Throwable cause) {
        super(message, cause);
    }
}